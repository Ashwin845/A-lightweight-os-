# .C OS - Architecture & Implementation Guide

## Design Philosophy

.C OS is built on these core principles:

1. **Educational**: Well-commented code for learning
2. **Portable**: Targets both emulators and real hardware
3. **Modular**: Separate drivers, filesystem, memory management
4. **Standards-Compliant**: x86_64 ABI, Multiboot2, FAT32
5. **Performance**: Direct hardware access, minimal overhead

## System Architecture

### Boot Sequence

```
Power-On
    ↓
BIOS POST
    ↓
GRUB Bootloader (if on real HW)
    ↓
boot.asm (_start)
    - Check multiboot magic
    - Setup GDT for 64-bit
    - Clear BSS section
    ↓
Jump to 64-bit mode (bits64_entry)
    - Reload segment registers
    ↓
kernel_main() [kernel.c]
    - Initialize PMM (physical memory)
    - Initialize VMM (virtual memory)
    - Initialize IDT (interrupts)
    - Initialize scheduler
    - Initialize drivers (VGA, AHCI, serial)
    - Initialize filesystem (FAT32)
    - Enable interrupts
    - Enter main kernel loop
    ↓
Main Kernel Loop
    - schedule() called on timer interrupt
    - System calls dispatched to handlers
```

### Memory Layout

```
Virtual Address Space (x86_64):
┌─────────────────────────────┐ 0xFFFFFFFFFFFFFFFF
│ Kernel Space (512GB)        │
│ - Code (.text)              │
│ - Data (.data, .bss)        │ 0xFFFFFFFF80000000
│ - Heap (growing down)       │
│ - Stacks (per-task)         │
├─────────────────────────────┤ 0x00007FFFFFFFFFFF
│ User Space                  │
│ - User programs             │
│ - User heap/stack           │
└─────────────────────────────┘ 0x0000000000000000

Physical Address Space:
┌─────────────────────────────┐ 0x100000000 (4GB)
│ Available for allocation    │
├─────────────────────────────┤
│ I/O Regions                 │
│ - MMIO (video, AHCI, etc)   │
├─────────────────────────────┤ 0x100000 (1MB)
│ Kernel loaded here          │
│ (by bootloader)             │
├─────────────────────────────┤ 0xB8000
│ VGA Text VRAM               │
├─────────────────────────────┤ 0xA0000
│ Legacy BIOS area            │
├─────────────────────────────┤ 0x00000
```

## Core Module Descriptions

### 1. Bootloader (boot/)

**Files**: `boot.asm`, `gdt.asm`, `multiboot2.h`

Responsibilities:
- Parse multiboot2 structure from GRUB
- Set up 64-bit paging (minimal page tables)
- Load Global Descriptor Table (GDT)
- Switch CPU to 64-bit long mode
- Jump to kernel_main()

Key functions:
```asm
_start           # Entry point
bits64_entry     # 64-bit setup
```

### 2. Virtual Memory Manager (src/vmm.c)

**Handles**: Virtual address translation, page table management

Data structures:
```c
pml4_table_t    # 512 level-4 entries
pdpt_table_t    # 512 level-3 entries
pd_table_t      # 512 level-2 entries (PD)
pt_table_t      # 512 level-1 entries (PT)
```

Key functions:
- `vmm_initialize()` - Set up kernel page tables
- `vmm_map_page()` - Map virtual→physical
- `vmm_translate()` - Virtual→physical lookup

### 3. Physical Memory Manager (src/pmm.c)

**Handles**: Physical frame allocation, memory accounting

Data structure:
```c
uint64_t bitmap[131072]  // 1 bit per 4KB frame (supports 8GB)
```

Key functions:
- `pmm_initialize()` - Initialize bitmap
- `pmm_allocate_frame()` - Get free physical frame
- `pmm_free_frame()` - Release frame
- `pmm_get_available()` - Query free memory

### 4. Kernel Heap (src/heap.c)

**Handles**: Dynamic memory allocation for kernel

Allocator types:
- **Slab caches**: 16, 32, 64, 128, 256 byte fixed-size pools
- **Buddy allocator**: Larger (1MB+) variable-size blocks

Key functions:
- `heap_initialize()` - Set up caches
- `kmalloc()` - Allocate memory
- `kfree()` - Deallocate memory
- `heap_coalesce()` - Merge free blocks

### 5. Scheduler (src/scheduler.c)

**Handles**: Process management, task scheduling

Data structures:
```c
tcb_t               # Task Control Block
task_table[256]     # All tasks
ready_queue_head    # Linked list of ready tasks
```

Key functions:
- `scheduler_initialize()` - Set up task structures
- `create_task()` - Create new task
- `schedule()` - Run scheduler (called on timer tick)
- `kill_task()` - Terminate task

Scheduling algorithm: **Round-Robin** (20 timeslice ticks per task)

### 6. Interrupts (src/interrupts.c)

**Handles**: IDT setup, IRQ/exception dispatching

Data structures:
```c
idt_gate_t idt[256]        # Interrupt Descriptor Table
interrupt_handler_t[256]   # Handler function pointers
```

Key functions:
- `idt_initialize()` - Set up IDT
- `set_interrupt_handler()` - Register handler
- `exception_handler_*()` - Exception stubs
- `irq_handler_*()` - Hardware interrupt handlers

Exceptions:
- #DE: Division by Zero
- #BP: Breakpoint
- #GP: General Protection Fault
- #PF: Page Fault

IRQs (via PIC):
- IRQ0: PIT (timer) → scheduler
- IRQ1: Keyboard
- IRQ4: Serial (COM1)
- IRQ14/15: AHCI storage

### 7. System Calls (src/syscalls.c)

**Handles**: User→kernel interface

Setup:
- SYSCALL/SYSRET MSRs configured
- Entry point: `syscall_entry()` (boot/syscall_entry.asm)
- Dispatcher: `syscall_dispatcher()` (validates & routes)

Security:
- Checks user addresses don't trespass into 0xFFFFFFFF80000000+
- Privilege validation before kernel operations

Syscall table:
```c
SYS_GET_PID (5)      → returns current process ID
SYS_EXIT (60)        → terminate task
SYS_SND_BEEP (3)     → control PC speaker
SYS_KPRINTF (1)      → log to kernel
SYS_OPEN_FILE (2)    → filesystem access
```

### 8. Drivers

#### VGA Driver (drivers/vga.c)

Two modes:
1. **Text mode** (80×25)
   - Direct VRAM write at 0xB8000
   - Character + color attribute

2. **Framebuffer** (graphics)
   - Linear framebuffer (1024×768×32bpp typical)
   - Double-buffered for flicker-free rendering

Key functions:
```c
vga_initialize()
vga_write_char()
vga_clear_screen()
fb_draw_pixel()
fb_draw_rectangle()
fb_swap_buffers()    // Fast assembly copy
```

#### Serial Driver (src/serial.c)

**Port**: COM1 (0x3F8), 115200 baud, 8N1

Used for debugging output (kernel logging)

Key functions:
```c
serial_initialize()  // Setup UART
serial_putchar()     // Write byte
serial_getchar()     // Read byte
```

#### AHCI Driver (drivers/ahci.c)

**Status**: Mock implementation (framework in place)

Real implementation would:
1. Scan PCI for AHCI controllers
2. Map MMIO space
3. Set up command queues
4. Issue ATA commands to drives

Key functions:
```c
ahci_initialize()
ahci_read_sector()   // LBA read
ahci_write_sector()  // LBA write
```

### 9. Filesystem (fs/fat32.c)

**Supports**: FAT32 (12-bit FAT, 32-bit cluster numbers)

Data structures:
```c
fat32_bpb_t         # BIOS Parameter Block
fat32_direntry_t    # Directory entry (32 bytes each)
fat32_file_t        # Open file handle
```

Key functions:
```c
fat32_initialize()
fat32_open()        // Open file
fat32_read()        // Read bytes
fat32_write()       // Write bytes
fat32_close()       // Close file
```

## Control Flow Examples

### Example 1: Process Scheduling

```
Timer Interrupt (IRQ0)
    ↓
irq_handler_0() [interrupts.c]
    ↓
schedule() [scheduler.c]
    - Check current_task->timeslice
    - If expired, rotate to next ready task
    - Call switch_task_context() [asm]
    ↓
switch_task_context()
    - Save CPU registers to old stack
    - Load new stack pointer
    - Restore CPU registers
    - Return to new task's RIP
```

### Example 2: System Call

```
User Program
    ↓
syscall (RAX=5, RDI=arg1)
    ↓
CPU trap → Ring 0
    ↓
syscall_entry() [boot/syscall_entry.asm]
    ↓
syscall_dispatcher(5, arg1, ...) [src/syscalls.c]
    - Validate arguments
    - Route by syscall ID
    - Execute handler
    ↓
Return (RAX = result)
    ↓
sysretq → User mode
```

### Example 3: Page Fault

```
User program reads invalid address
    ↓
#PF Exception (IRQ14)
    ↓
exception_handler_14()
    ↓
[Could be: COW page, lazy allocation, invalid access, etc.]
    ↓
kpanic() if invalid
    ↓
Resume or terminate process
```

## Performance Considerations

### Memory Allocation
- Slab caches: O(1) allocation for common sizes
- Buddy allocator: O(log n) for larger blocks
- Coalescing: Reduces fragmentation over time

### Scheduling
- Round-robin: Fair, simple, O(n) context switches
- Could improve with: Priority queues, load balancing

### Page Tables
- 4-level paging: Deep walks (4 memory accesses per TLB miss)
- Optimization: TLB caching by CPU (managed by hardware)

## Extending the Kernel

### Adding a New System Call

1. **Define syscall ID** in `include/kernel.h`:
   ```c
   #define SYS_MY_CALL 100
   ```

2. **Implement handler** in `src/syscalls.c`:
   ```c
   case SYS_MY_CALL:
       // Handler code
       return result;
   ```

3. **Test from user space**:
   ```c
   uint64_t result;
   asm("mov $100, %rax; syscall" : "=a"(result));
   ```

### Adding a Device Driver

1. Create `drivers/mydevice.c`
2. Implement:
   - `mydevice_initialize()`
   - Device-specific functions
3. Register interrupt handler if needed
4. Call from `kernel_main()`

### Adding Filesystem Support

1. Create `fs/myfs.c`
2. Implement interface:
   - `myfs_open()`
   - `myfs_read()`
   - `myfs_write()`
   - `myfs_close()`
3. Mount filesystem in VFS layer (to be added)

## Testing & Verification

### Unit Testing
```c
void test_pmm() {
    uint64_t frame1 = pmm_allocate_frame();
    uint64_t frame2 = pmm_allocate_frame();
    assert(frame1 != frame2);
    pmm_free_frame(frame1);
    assert(pmm_get_available() > 0);
}
```

### Integration Testing
- Boot in QEMU
- Observe serial output
- Debug with GDB

### Stress Testing
```bash
# Multiple tasks
for i in {1..100}; do
    create_task("stress_$i", stress_work, 1);
done
```

## Debugging Tips

1. **Add debug output**: `KLOG()` macro → serial port
2. **Use breakpoints**: GDB with QEMU
3. **Check memory**: `x/10x $rsp` in GDB
4. **Trace syscalls**: `strace` on user program
5. **Monitor CPU**: `top`, `htop` on host

---

This architecture provides a solid foundation for learning OS kernel development while remaining close enough to real-world designs to be meaningful.
