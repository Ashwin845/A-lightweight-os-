#!/bin/bash
# verify_build.sh - Verify kernel build and generate diagnostics

set -e

echo "================================"
echo ".C OS Build Verification Script"
echo "================================"
echo ""

# Check build artifacts
echo "[1/5] Checking build artifacts..."

if [ ! -f build/kernel.bin ]; then
    echo "❌ ERROR: build/kernel.bin not found!"
    echo "   Run: make clean && make"
    exit 1
fi

if [ ! -f build/kernel.elf ]; then
    echo "❌ ERROR: build/kernel.elf not found!"
    exit 1
fi

KERNEL_SIZE=$(ls -lh build/kernel.bin | awk '{print $5}')
echo "✓ Kernel binary found: $KERNEL_SIZE"
echo "  Path: $(pwd)/build/kernel.bin"
echo ""

# Check multiboot header
echo "[2/5] Checking multiboot2 header..."

if strings build/kernel.bin | grep -q "GRUB"; then
    echo "✓ Grub multiboot header detected"
else
    echo "⚠ Warning: Multiboot header not found (may still work with -kernel)"
fi
echo ""

# Check for expected symbols
echo "[3/5] Checking kernel symbols..."

if [ -x "$(command -v nm)" ]; then
    if nm build/kernel.elf | grep -q "kernel_main"; then
        echo "✓ kernel_main symbol found"
    fi
    if nm build/kernel.elf | grep -q "schedule"; then
        echo "✓ schedule symbol found"
    fi
    echo ""
fi

# Generate disassembly
echo "[4/5] Generating disassembly (first 100 instructions)..."

if [ -x "$(command -v objdump)" ]; then
    objdump -d build/kernel.elf | head -150 > build/kernel_disasm_sample.txt
    echo "✓ Disassembly: build/kernel_disasm_sample.txt"
    echo ""
fi

# Summary
echo "[5/5] Build Summary"
echo "==================="
echo "Binary:   build/kernel.bin"
echo "ELF:      build/kernel.elf"
echo "Size:     $KERNEL_SIZE"
echo ""

# Try to detect architecture
if file build/kernel.elf | grep -q "x86-64"; then
    echo "✓ Architecture: x86-64 64-bit"
else
    echo "⚠ Architecture detection inconclusive"
fi

echo ""
echo "✅ Build verification complete!"
echo ""
echo "Next steps:"
echo "  1. Run in QEMU:        make qemu"
echo "  2. Debug with GDB:     make qemu-debug (then in another terminal: gdb ...)"
echo "  3. View disassembly:   objdump -d build/kernel.elf | less"
echo "  4. View symbols:       nm build/kernel.elf"
echo ""
