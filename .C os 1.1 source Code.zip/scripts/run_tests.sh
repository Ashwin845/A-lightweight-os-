#!/bin/bash
# run_tests.sh - Run kernel tests in QEMU

set -e

TEST_TIMEOUT=30
QEMU_CMD="qemu-system-x86_64 -m 1024 -kernel build/kernel.bin"

echo "================================"
echo ".C OS Test Suite"
echo "================================"
echo ""

# Check if kernel exists
if [ ! -f build/kernel.bin ]; then
    echo "❌ Kernel not built. Run: make clean && make"
    exit 1
fi

echo "Test 1: Basic Boot"
echo "================="
timeout $TEST_TIMEOUT $QEMU_CMD -serial file:test_boot.log -nographic 2>/dev/null || true

if grep -q "KERNEL INITIALIZATION COMPLETE" test_boot.log; then
    echo "✓ Kernel booted successfully"
    echo "✓ All initialization modules loaded"
else
    echo "❌ Boot failed - check test_boot.log"
    cat test_boot.log
    exit 1
fi
echo ""

echo "Test 2: Memory Check"
echo "===================="
if grep -q "Available physical memory" test_boot.log; then
    MEM_LINE=$(grep "Available physical memory" test_boot.log)
    echo "✓ $MEM_LINE"
else
    echo "⚠ Memory info not found"
fi
echo ""

echo "Test 3: Driver Initialization"
echo "============================="

DRIVERS=("VGA display" "AHCI driver" "FAT32 filesystem" "scheduler")

for driver in "${DRIVERS[@]}"; do
    if grep -q "$driver" test_boot.log; then
        echo "✓ $driver initialized"
    else
        echo "⚠ $driver not mentioned in boot log"
    fi
done
echo ""

echo "Test Summary"
echo "============"
echo "Boot log: test_boot.log"
echo "Build output: build/kernel.elf, build/kernel.bin"
echo ""
echo "✅ Basic tests passed!"
echo ""
